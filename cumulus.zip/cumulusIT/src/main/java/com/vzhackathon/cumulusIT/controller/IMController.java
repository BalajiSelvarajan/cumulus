package com.vzhackathon.cumulusIT.controller;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.vzhackathon.cumulusIT.model.InformationManager;

@RestController
@RequestMapping("/im")
//@Path("/employee/")
public class IMController {
	
	 @RequestMapping(value="/software/{name}", method=RequestMethod.GET)
	    public InformationManager getEmployee(@PathVariable String name)
	    {
		 InformationManager im = new InformationManager();
		 if(name.equals("oracle"))
		 {
			 im.setSoftwareid("1212");
			 im.setSoftwarename("Oracle Enterprise Edition");
			 im.setLicence("Unlimited License Agreement (ULA)");
			 im.setPath("http://www.oracle.com/technetwork/java/javase/downloads/index.html");
			 im.setVersion("Java Platform (JDK) 8u131");
			 im.setReferenceLink("https://www.youtube.com/watch?v=d_CyuCLC3Ls");
		 }
		 
		 else if(name.equals("java"))
		 {
			 im.setSoftwareid("1421");
			 im.setSoftwarename("Java Standard Edition");
			 im.setLicence("Oracle Binary Code License (BCL)");
			 im.setPath("http://www.oracle.com/webfolder/technetwork/tutorials/obe/db/11g/r1/prod/install/dbinst/windbinst2.htm#i");
			 im.setVersion("12g version");
			 im.setReferenceLink("https://www.youtube.com/watch?v=gfIrwdjrV5s");
		 }
	    	return im;
	    }
}
