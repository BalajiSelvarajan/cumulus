package com.vzhackathon.cumulusIT.model;

public class InformationManager {
	private String softwareid;
	private String softwarename;	
	private String version;
	private String licence;
	private String path;
	private String referenceLink;
	
	
	public String getSoftwareid() {
		return softwareid;
	}
	public void setSoftwareid(String softwareid) {
		this.softwareid = softwareid;
	}
	public String getSoftwarename() {
		return softwarename;
	}
	public void setSoftwarename(String softwarename) {
		this.softwarename = softwarename;
	}
	public String getVersion() {
		return version;
	}
	public void setVersion(String version) {
		this.version = version;
	}
	public String getLicence() {
		return licence;
	}
	public void setLicence(String licence) {
		this.licence = licence;
	}
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}
	public String getReferenceLink() {
		return referenceLink;
	}
	public void setReferenceLink(String referenceLink) {
		this.referenceLink = referenceLink;
	}
	
	

}
